SAMPFUNCS v5.4.1-final for SA-MP 0.3.7-R1

Copyright (c) 2013-2018, BlastHack Team <blast.hk>

https://blast.hk/sampfuncs/
https://blast.hk/wiki/sampfuncs:start
