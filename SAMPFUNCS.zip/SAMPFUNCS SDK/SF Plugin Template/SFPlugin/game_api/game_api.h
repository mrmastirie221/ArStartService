#ifndef GAME_API_H__
#define GAME_API_H__

#include "sdk/SharedUtil.h"
#include "game/CGame.h"

extern CGame SAMPFUNCS_API *GAME;
extern CPed SAMPFUNCS_API *PEDSELF;

#endif // GAME_API_H__
